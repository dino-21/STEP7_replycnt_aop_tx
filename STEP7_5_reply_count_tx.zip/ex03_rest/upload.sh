git add .
git commit -m "test"
git push origin main